Tudo em Oferta 123 - Pacote de site (5 páginas)
===============================================

Arquivos incluídos:
- index.html
- roupas.html
- beleza.html
- eletronicos.html
- ebooks.html
- README.md (este arquivo)

INSTRUÇÕES RÁPIDAS
------------------
1) Editar links e imagens:
   - Abra cada arquivo .html em um editor de texto (ex: Notepad, VSCode).
   - Substitua os marcadores do tipo REPLACE_LINK_* pelos seus links de afiliado (Shopee, Hotmart, Amazon etc).
   - Se quiser trocar imagens, hospede a imagem (ex: https://postimages.org/) e coloque o URL no atributo src da tag <img>.

2) Testar localmente:
   - Abra os arquivos .html no seu navegador (double-click). A navegação entre páginas usa links relativos (index.html -> roupas.html).

3) Publicar com GitHub Pages (recomendado):
   - Crie uma conta no https://github.com/ (se ainda não tiver).
   - Crie um novo repositório (ex: tudoemoferta123).
   - Faça upload dos arquivos (Add file → Upload files).
   - Vá em Settings → Pages (ou Settings → Code and automation → Pages), selecione Branch: main e / (root), salve.
   - Aguarde o link aparecer (ex: https://seunome.github.io/tudoemoferta123/).
   - Use esse URL como o link da sua bio no Instagram.

4) Incorporar no Google Sites (opcional):
   - Publique primeiro no GitHub Pages (ou em outro host).
   - No Google Sites (sites.google.com), crie um site novo.
   - Use Inserir → Incorporar → (URL) → cole o link do GitHub Pages.
     - Ajuste a caixa incorporada para caber no layout.
   - Publicar o Google Site (endereço do Google Sites será algo tipo https://sites.google.com/view/tudoemoferta123).
   - Observação: o Google Sites não hospeda arquivos HTML puros; por isso recomendamos hospedar externamente (GitHub Pages) e incorporar por URL.

5) Editar depois (direto no GitHub):
   - No repositório GitHub, clique no arquivo → ícone de lápis → edite → Commit changes.
   - As alterações vão para a página publicada em poucos minutos.

6) Dicas rápidas:
   - Sempre teste os links de afiliado antes de divulgar.
   - Use imagens limpas, preferencialmente sem marcas d'água.
   - Mantenha a página leve (imagens otimizadas) para carregar rápido no celular.

Se quiser, eu já posso atualizar os arquivos com os seus links/imagens agora — me envie os links dos produtos e capas de ebook e eu substituo nos arquivos para você.
